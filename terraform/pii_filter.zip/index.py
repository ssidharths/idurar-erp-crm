import json
import boto3
import gzip
import base64
import re
import os
from datetime import datetime

def handler(event, context):
    """
    Lambda function to filter PII from CloudWatch logs
    """
    cw_logs = boto3.client('logs')
    
    # Parse the CloudWatch Logs event
    cw_data = event['awslogs']['data']
    compressed_payload = base64.b64decode(cw_data)
    uncompressed_payload = gzip.decompress(compressed_payload)
    log_data = json.loads(uncompressed_payload)
    
    filtered_events = []
    
    for log_event in log_data['logEvents']:
        message = log_event['message']
        timestamp = log_event['timestamp']
        
        # Filter out PII using regex patterns
        filtered_message = filter_pii(message)
        
        if filtered_message != message:
            print(f"PII detected and filtered in log event at {timestamp}")
        
        filtered_events.append({
            'timestamp': timestamp,
            'message': filtered_message
        })
    
    # Send filtered logs to the filtered log group
    try:
        log_stream_name = f"filtered-{datetime.now().strftime('%Y/%m/%d')}/pii-filtered"
        
        # Create log stream if it doesn't exist
        try:
            cw_logs.create_log_stream(
                logGroupName=os.environ['FILTERED_LOG_GROUP'],
                logStreamName=log_stream_name
            )
        except cw_logs.exceptions.ResourceAlreadyExistsException:
            pass
        
        # Put filtered log events
        cw_logs.put_log_events(
            logGroupName=os.environ['FILTERED_LOG_GROUP'],
            logStreamName=log_stream_name,
            logEvents=filtered_events
        )
        
    except Exception as e:
        print(f"Error writing filtered logs: {str(e)}")
    
    return {
        'statusCode': 200,
        'body': json.dumps(f'Processed {len(filtered_events)} log events')
    }

def filter_pii(message):
    """
    Filter common PII patterns from log messages
    """
    # Email addresses
    message = re.sub(r'\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Z|a-z]{2,}\b', '[EMAIL-REDACTED]', message)
    
    # Phone numbers (various formats)
    message = re.sub(r'(\+\d{1,3}[-.\s]?)?\(?\d{3}\)?[-.\s]?\d{3}[-.\s]?\d{4}', '[PHONE-REDACTED]', message)
    
    # Credit card numbers
    message = re.sub(r'\b\d{4}[-\s]?\d{4}[-\s]?\d{4}[-\s]?\d{4}\b', '[CARD-REDACTED]', message)
    
    # SSN patterns
    message = re.sub(r'\b\d{3}-\d{2}-\d{4}\b', '[SSN-REDACTED]', message)
    
    # IP addresses (private info in some contexts)
    message = re.sub(r'\b(?:\d{1,3}\.){3}\d{1,3}\b', '[IP-REDACTED]', message)
    
    # Common password patterns in logs
    message = re.sub(r'(password|pwd|pass)[:=]\s*\S+', r'\1=[PASSWORD-REDACTED]', message, flags=re.IGNORECASE)
    
    # API keys and tokens
    message = re.sub(r'(api[_-]?key|token|secret)[:=]\s*[A-Za-z0-9+/=]{20,}', r'\1=[TOKEN-REDACTED]', message, flags=re.IGNORECASE)
    
    return message
